import React, { Component } from 'react';
import { View, Text } from 'react-native';
import { connect } from 'react-redux';

class PlaceList extends Component {

    static navigationOptions = {
        title: 'Place List',
    };

    render() {
        return (
            <View>
            </View>
        );
    }
}


export default PlaceList;