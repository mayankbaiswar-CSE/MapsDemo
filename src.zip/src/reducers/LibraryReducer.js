import { combineReducers } from 'react-redux';
import data from './LibraryList.json'

export default () => data;